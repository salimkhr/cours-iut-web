<?php
class User {
    // Déclaration des propriétés de l'utilisateur


    // Constructeur avec des types pour chaque propriété
    public function __construct(
        private string $name,
        private string $position,
        private array  $cards = [],
        private int    $score = 0,
    ) {}

    /**
     * @return string
     */
    public  function getName(): string
    {
        return $this->name;
    }/**
     * @param string $name
     * @return User
     */
    public function setName(string $name): User
    {
        $this->name = $name;
        return $this;
    }/**
     * @return int
     */
    public  function getScore(): int
    {
        return $this->score;
    }/**
     * @param int $score
     * @return User
     */
    public function setScore(int $score): User
    {
        $this->score = $score;
        return $this;
    }/**
     * @return string
     */
    public  function getPosition(): string
    {
        return $this->position;
    }/**
     * @param string $position
     * @return User
     */
    public function setPosition(string $position): User
    {
        $this->position = $position;
        return $this;
    }/**
     * @return array
     */
    public  function getCards(): array
    {
        return $this->cards;
    }/**
     * @param array $cards
     * @return User
     */
    public function setCards(array $cards): User
    {
        $this->cards = $cards;
        return $this;
    }

    public function AddCards(array $cards): void
    {
        $this->cards = array_merge($this->cards, $cards);
    }
}
?>
