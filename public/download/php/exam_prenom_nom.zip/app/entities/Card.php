<?php
class Card
{
    /* Présent uniquement pour éviter une erreur sur la page players.php à modifier pour renvoyer l'id de la carte  */
    public function getId():?int
    {
        return null;
    }

    /* Présent uniquement pour éviter une erreur sur la page index.php à modifier pour renvoyer le texte de la carte  */
    public function getText():string
    {
        return '';
    }
}