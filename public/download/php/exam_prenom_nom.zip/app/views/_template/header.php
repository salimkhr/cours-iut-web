<!DOCTYPE html>
<html class="light" lang="fr"><head>
    <meta charset="utf-8"/>
    <meta content="width=device-width, initial-scale=1.0" name="viewport"/>
    <title>Intranet BUT informatique du Havre - <?= $title ?></title>
    <script src="/js/tailwindcss.js"></script>
    <link href="/css/Poppins.css" rel="stylesheet"/>
    <link href="/css/Material.css" rel="stylesheet"/>
    <link href="/css/Material.css" rel="stylesheet"/>
    <style>
        .material-symbols-outlined {
            font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
        }
    </style>
    <script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: {
                        "primary": "#ff4d88",
                        "background-light": "#f8f5f6",
                        "background-dark": "#230f16",
                        "punchy-pink": "#FF4F8B",
                        "pastel-blue": "#6BCBFF",
                        "bright-yellow": "#FFD93D",
                        "soft-purple": "#A78BFA",
                        "text-light": "#181013",
                        "text-dark": "#f8f5f6",
                        "card-light": "#ffffff",
                        "card-dark": "#2a141c",
                        "card-border-light": "#e7dade",
                        "card-border-dark": "#4a2536",
                        "text-muted-light": "#8d5e6d",
                        "text-muted-dark": "#bfa6b2",
                        "rose-punchy": "#FF4F8B",
                    },
                    fontFamily: {
                        "display": ["Plus Jakarta Sans", "sans-serif"],
                        "poppins": ["Poppins", "sans-serif"]
                    },
                    borderRadius: {"DEFAULT": "1rem", "lg": "1.5rem", "xl": "3rem", "full": "9999px"},
                },
            },
        }
    </script>
</head>
<body class="font-display bg-background-light dark:bg-background-dark text-text-light dark:text-text-dark">
<div class="relative flex h-auto min-h-screen w-full flex-col group/design-root overflow-x-hidden">
    <div class="layout-container flex h-full grow flex-col">
        <div class="px-2 sm:px-4 md:px-6 lg:px-8 xl:px-12 flex flex-1 justify-center py-5">
            <div class="layout-content-container flex flex-col w-full max-w-[90%] flex-1">
                <header class="flex items-center justify-between whitespace-nowrap border-b border-solid border-card-border-light dark:border-card-border-dark px-4 sm:px-6 py-4 mb-8">
                    <div class="flex items-center gap-4">
                        <div class="size-6 text-punchy-pink">
                            <svg fill="none" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
                                <path clip-rule="evenodd" d="M12.0799 24L4 19.2479L9.95537 8.75216L18.04 13.4961L18.0446 4H29.9554L29.96 13.4961L38.0446 8.75216L44 19.2479L35.92 24L44 28.7521L38.0446 39.2479L29.96 34.5039L29.9554 44H18.0446L18.04 34.5039L9.95537 39.2479L4 28.7521L12.0799 24Z" fill="currentColor" fill-rule="evenodd"></path>
                            </svg>
                        </div>
                        <a href="index.php"><h1 class="text-xl font-bold leading-tight tracking-[-0.015em]">Département Informatique - 2024 / 2025</h1></a>
                    </div>

                    <div class="flex flex-1 justify-end gap-4">
                        <button class="flex max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-full h-10 w-10 bg-background-light dark:bg-card-dark text-text-light dark:text-text-dark gap-2 text-sm font-bold leading-normal tracking-[0.015em] min-w-0">
                            <span class="material-symbols-outlined text-2xl">notifications</span>
                        </button>
                        <a href="admin.php" class="flex max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-full h-10 w-10 bg-background-light dark:bg-card-dark text-text-light dark:text-text-dark gap-2 text-sm font-bold leading-normal tracking-[0.015em] min-w-0">
                            <span class="material-symbols-outlined text-2xl">settings</span>
                        </a>
                        <div class="bg-center bg-no-repeat aspect-square bg-cover rounded-full size-10" data-alt="User profile avatar" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuDS9JG02pTmajL31KV-uCznG7XDwA3vhTU_NZ64LW0AFdToiv6cXBqaMnIliEZnWu87cgNG746er9-KCXhrNCl2s7XyaFXqnfBBVhOLbYOFbYYONoBi3VuGqiwTVNPGehmgao2USkchtbleOmO-HfRaLMqBJKuCfGjjnnF-8xjkhs8-so3OShaHQ7EltOdTyzvfTCV5vRvmcjIwLHDW-kdT8iEAclkhN4rRMv3tzZwmFxjYQYMZRY6bxevxcF5SdEpsAmLKHRGx4c4");'></div>
                    </div>
                </header>