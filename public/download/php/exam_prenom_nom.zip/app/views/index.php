<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jeu Limite Limite avec Vue.js</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/vue.js"></script>
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="bg-light text-dark">
<div id="app" class="container-fluid position-relative vh-100">
    <a class="btn btn-outline-danger mt-3" href="init.php">Réinitialiser la partie</a>
    <a class="btn btn-outline-success mt-3 ms-2" href="article_create.php">Ajouter une carte</a>
    <!-- Joueurs -->
    <div v-for="joueur in joueurs" :key="joueur.id" :class="`joueur text-center joueur-${joueur.position}`">
        <h4>{{ joueur.nom }}</h4>
        <h6>Score : {{ joueur.score }}</h6>
        <div :class="`cartes-${joueur.position}`">
            <div class="card carte-blanche m-2 bg-danger" style="width: 120px;"
                 v-for="carte in joueur.cartesBlanches"
                 :key="carte.id"
                 :draggable="joueur.position === 'bottom'"
                 @dragstart="joueur.position === 'bottom' && commencerGlisser(carte)">
                <div class="card-body d-flex align-items-center justify-content-center">
                    <template v-if="joueur.position === 'bottom'">
                        <p class="card-text">{{ carte.texte }}</p>
                    </template>
                    <template v-else>
                        <img src="images/limitelimite.png" class="card-img-top img-fluid" alt="Carte">
                    </template>
                </div>
            </div>
        </div>
    </div>

    <!-- Carte Noire Section -->
    <div class="row justify-content-center align-items-center vh-50">
        <div class="col-md-6">
            <div class="card text-center bg-dark text-white" id="carteNoire"
                 @dragover.prevent="highlightDropzone(true)"
                 @dragleave="highlightDropzone(false)"
                 @drop="deposerCarte">
                <div class="card-body">
                    <p class="card-text">{{ carteNoire }}</p>
                </div>
                <!-- Cartes Jouées -->
                <div v-if="cartesJouees.length || cartesJoueesAutomatique.length" class="mt-4">
                    <h4>Cartes Jouées :</h4>
                    <div class="d-flex justify-content-center flex-wrap">
                        <div v-for="(carte, index) in cartesJouees" :key="index"
                             class="card carte-blanche m-2 bg-danger">
                            <div class="card-body d-flex align-items-center justify-content-center">
                                <p class="card-text">{{ carte.texte }}</p>
                            </div>
                        </div>
                        <div v-for="(carte, index) in cartesJoueesAutomatique" :key="index"
                             class="card carte-blanche m-2 bg-danger">
                            <div class="card-body d-flex align-items-center justify-content-center">
                                <img src="images/limitelimite.png" class="card-img-top img-fluid" alt="Carte">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="js/bootstrap.min.js"></script>
<script src="js/app.js"></script>
</body>
</html>
