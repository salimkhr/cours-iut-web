<?php
require_once '../app/views/_template/header.php';
?>
<main class="flex flex-col gap-8">
                    <div class="@container bg-punchy-pink/10 dark:bg-punchy-pink/20 rounded-lg">
                        <div class="flex flex-col items-stretch justify-start rounded-lg @xl:flex-row @xl:items-center bg-card-light dark:bg-card-dark shadow-sm">
                            <div class="w-full bg-center bg-no-repeat aspect-video bg-cover rounded-t-lg @xl:rounded-l-lg @xl:rounded-r-none @xl:max-w-xs" data-alt="Illustration of a calendar and a clock" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuANgHmvY2hYV6Fi33fitszx2W0SL9RiWs0KVZ7qzIHHv9DRpoFPlQJaELmvbjN4c_5PMOLIxdghrusqISO0F5tVn-KNteqeED_PLpLjtNzzZ4y2mcR9CRPdXd39kjrJfDgvreI2DaUeO3VIuXi-ZRUbfV40O_1P8i0nvScsx4WVDoDNHaG6aFjtCcmMIUk5Mazbp-rimnCdWGuqbFjBbhxFgj9M2rpTzQJ06g32qaMkdqpGEN4MMNXY-C6ZoINpXN2ILiKCmrFpZjc");'></div>
                            <div class="flex w-full min-w-72 grow flex-col items-stretch justify-center gap-2 p-6 @xl:px-8">
                                <p class="text-xl font-bold leading-tight tracking-[-0.015em]">Planning Entretiens Individuels – Octobre</p>
                                <div class="flex flex-col @md:flex-row items-start @md:items-end gap-4 justify-between">
                                    <p class="text-text-muted-light dark:text-text-muted-dark text-base font-normal leading-normal flex-1">
                                        Consultez le calendrier complet et réservez votre créneau pour les entretiens individuels du mois d'octobre.
                                    </p>
                                    <button class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-full h-10 px-6 bg-punchy-pink text-white text-sm font-bold leading-normal">
                                        <span class="truncate">Voir le planning</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <section>
                        <h2 class="text-2xl font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5">Enseignement</h2>
                        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 p-4">

                            <!-- Année 1 -->
                            <a class="min-h-[200px] group relative flex flex-col justify-between overflow-hidden rounded-lg bg-pastel-blue p-6 transition-transform duration-300 ease-in-out hover:-translate-y-2 hover:scale-105" href="year.php?y=1">
                                <div class="absolute -right-8 -top-8 text-white/20 transition-transform duration-500 ease-out group-hover:scale-110 group-hover:rotate-6">
                                    <span class="material-symbols-outlined !text-[160px] !font-light">school</span>
                                </div>
                                <div class="relative z-10">
                                    <p class="font-poppins text-5xl sm:text-6xl font-extrabold text-white">1ère</p>
                                    <p class="font-poppins text-4xl sm:text-5xl font-bold text-white/50">Année</p>
                                </div>
                                <div class="relative z-10 flex items-center justify-between">
                                    <p class="text-base font-semibold text-white">Découvrir le programme</p>
                                    <span class="material-symbols-outlined text-white transition-transform duration-300 ease-in-out group-hover:translate-x-1">arrow_forward</span>
                                </div>
                            </a>

                            <!-- Année 2 -->
                            <a class="min-h-[200px] group relative flex flex-col justify-between overflow-hidden rounded-lg bg-bright-yellow p-6 transition-transform duration-300 ease-in-out hover:-translate-y-2 hover:scale-105" href="year.php?y=2">
                                <div class="absolute -right-8 -top-8 text-black/10 transition-transform duration-500 ease-out group-hover:scale-110 group-hover:rotate-6">
                                    <span class="material-symbols-outlined !text-[160px] !font-light">lightbulb</span>
                                </div>
                                <div class="relative z-10">
                                    <p class="font-poppins text-5xl sm:text-6xl font-extrabold text-black/80">2ème</p>
                                    <p class="font-poppins text-4xl sm:text-5xl font-bold text-black/40">Année</p>
                                </div>
                                <div class="relative z-10 flex items-center justify-between">
                                    <p class="text-base font-semibold text-black/80">Découvrir le programme</p>
                                    <span class="material-symbols-outlined text-black/80 transition-transform duration-300 ease-in-out group-hover:translate-x-1">arrow_forward</span>
                                </div>
                            </a>

                            <!-- Année 3 -->
                            <a class="min-h-[200px] group relative flex flex-col justify-between overflow-hidden rounded-lg bg-punchy-pink p-6 transition-transform duration-300 ease-in-out hover:-translate-y-2 hover:scale-105" href="year.php?y=3">
                                <div class="absolute -right-8 -top-8 text-white/20 transition-transform duration-500 ease-out group-hover:scale-110 group-hover:rotate-6">
                                    <span class="material-symbols-outlined !text-[160px] !font-light">rocket_launch</span>
                                </div>
                                <div class="relative z-10">
                                    <p class="font-poppins text-5xl sm:text-6xl font-extrabold text-white">3ème</p>
                                    <p class="font-poppins text-4xl sm:text-5xl font-bold text-white/50">Année</p>
                                </div>
                                <div class="relative z-10 flex items-center justify-between">
                                    <p class="text-base font-semibold text-white">Découvrir le programme</p>
                                    <span class="material-symbols-outlined text-white transition-transform duration-300 ease-in-out group-hover:translate-x-1">arrow_forward</span>
                                </div>
                            </a>

                        </div>

                    </section>
                    <section>
                        <h2 class="text-2xl font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5">Ressources &amp; Informations</h2>
                        <div class="grid grid-cols-[repeat(auto-fit,minmax(200px,1fr))] gap-4 p-4">
                            <div class="flex flex-1 gap-4 rounded-lg border border-card-border-light dark:border-card-border-dark bg-card-light dark:bg-card-dark p-4 flex-col">
                                <span class="material-symbols-outlined text-3xl text-pastel-blue">gavel</span>
                                <div class="flex flex-col gap-1">
                                    <h3 class="text-lg font-bold leading-tight">Règlement</h3>
                                    <p class="text-sm font-normal leading-normal text-text-muted-light dark:text-text-muted-dark">Consultez les règles du département</p>
                                </div>
                            </div>
                            <div class="flex flex-1 gap-4 rounded-lg border border-card-border-light dark:border-card-border-dark bg-card-light dark:bg-card-dark p-4 flex-col">
                                <span class="material-symbols-outlined text-3xl text-bright-yellow">info</span>
                                <div class="flex flex-col gap-1">
                                    <h3 class="text-lg font-bold leading-tight">Infos</h3>
                                    <p class="text-sm font-normal leading-normal text-text-muted-light dark:text-text-muted-dark">Annonces générales et actualités</p>
                                </div>
                            </div>
                            <div class="flex flex-1 gap-4 rounded-lg border border-card-border-light dark:border-card-border-dark bg-card-light dark:bg-card-dark p-4 flex-col">
                                <span class="material-symbols-outlined text-3xl text-soft-purple">book_2</span>
                                <div class="flex flex-col gap-1">
                                    <h3 class="text-lg font-bold leading-tight">Documentation</h3>
                                    <p class="text-sm font-normal leading-normal text-text-muted-light dark:text-text-muted-dark">Guides techniques et logiciels</p>
                                </div>
                            </div>
                            <div class="flex flex-1 gap-4 rounded-lg border border-card-border-light dark:border-card-border-dark bg-card-light dark:bg-card-dark p-4 flex-col">
                                <span class="material-symbols-outlined text-3xl text-punchy-pink">celebration</span>
                                <div class="flex flex-col gap-1">
                                    <h3 class="text-lg font-bold leading-tight">Divers</h3>
                                    <p class="text-sm font-normal leading-normal text-text-muted-light dark:text-text-muted-dark">Vie étudiante, événements et plus</p>
                                </div>
                            </div>
                            <div class="flex flex-1 gap-4 rounded-lg border border-card-border-light dark:border-card-border-dark bg-card-light dark:bg-card-dark p-4 flex-col">
                                <span class="material-symbols-outlined text-3xl text-soft-purple">database</span>
                                <div class="flex flex-col gap-1">
                                    <h3 class="text-lg font-bold leading-tight">Ressources</h3>
                                    <p class="text-sm font-normal leading-normal text-text-muted-light dark:text-text-muted-dark">Outils en ligne et accès serveurs</p>
                                </div>
                            </div>
                            <div class="flex flex-1 gap-4 rounded-lg border border-card-border-light dark:border-card-border-dark bg-card-light dark:bg-card-dark p-4 flex-col">
                                <span class="material-symbols-outlined text-3xl text-pastel-blue">business_center</span>
                                <div class="flex flex-col gap-1">
                                    <h3 class="text-lg font-bold leading-tight">SAÉ</h3>
                                    <p class="text-sm font-normal leading-normal text-text-muted-light dark:text-text-muted-dark">Projets étudiants et ressources</p>
                                </div>
                            </div>
                            <div class="flex flex-1 gap-4 rounded-lg border border-card-border-light dark:border-card-border-dark bg-card-light dark:bg-card-dark p-4 flex-col">
                                <span class="material-symbols-outlined text-3xl text-bright-yellow">description</span>
                                <div class="flex flex-col gap-1">
                                    <h3 class="text-lg font-bold leading-tight">Administratif</h3>
                                    <p class="text-sm font-normal leading-normal text-text-muted-light dark:text-text-muted-dark">Formulaires et contacts utiles</p>
                                </div>
                            </div>
                        </div>
                    </section>
                </main>
<?php
require_once '../app/views/_template/footer.php';
?>