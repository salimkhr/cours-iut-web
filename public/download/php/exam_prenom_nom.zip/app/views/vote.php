<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jeu Limite Limite avec Vue.js</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="js/vue.js"></script>
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="bg-light text-dark">
<div id="app" class="container-fluid position-relative vh-100">
    <a class="btn btn-outline-danger mt-3" href="init.php">Réinitialiser la partie</a>
    <a class="btn btn-outline-success mt-3 ms-2" href="article_create.php">Ajouter une carte</a>
    <!-- Joueurs -->
    <div v-for="(joueur, index) in joueurs" :key="joueur.id" :class="`joueur text-center joueur-${joueur.position}`">
        <h4>{{ joueur.nom }}</h4>
        <h6>Score : {{ joueur.score }}</h6>

        <!-- Affichage de la carte sélectionnée pour chaque joueur -->
        <div class="card carte-blanche m-2 bg-danger" style="width: 120px;">
            <div class="card-body d-flex align-items-center justify-content-center">
                <p class="card-text">{{ joueur?.carteSelectionnee?.texte }}</p>
            </div>
        </div>

        <button  @click="attribuerPoint(index)" class="btn btn-primary mt-3" >
            Attribuer le point
        </button>
    </div>

    <!-- Carte Noire Section -->
    <div class="row justify-content-center align-items-center">
        <div class="col-md-6">
            <div class="card text-center bg-dark text-white" style="position: absolute;top: 40vh;transform: translateX(-50%);left: 50%;width:300px">
                <div class="card-body">
                    <p class="card-text">{{ carteNoire }}</p>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="js/bootstrap.min.js"></script>
<script src="js/appVote.js"></script>

</body>
</html>
