<?php
require_once '../app/views/_template/header.php';
?>
    <main class="flex flex-col gap-4 mt-6">
        <!-- PageHeading -->
        <div class="flex flex-wrap justify-between items-center gap-3 p-4">
            <p class="text-slate-900 dark:text-white text-4xl font-black leading-tight tracking-[-0.033em] min-w-72">Semestre </p>
        </div>
        <!-- SegmentedButtons -->
        <div class="flex px-4 py-3">
            <div class="flex h-10 flex-1 items-center justify-center rounded-full bg-black/5 dark:bg-white/5 p-1">
                <?php for ($i = 1; $i <= 6; $i++):
                    $yForLink = intval(ceil($i / 2)); // calculer l'année pour ce semestre
                    ?>
                    <a
                            href="year.php?y=<?= $yForLink ?>&s=<?= $i ?>"
                            class="flex cursor-pointer h-full grow items-center justify-center overflow-hidden rounded-full px-2
                       <?= ($i === $semestreActif) ? 'bg-white dark:bg-background-dark shadow-[0_0_8px_rgba(0,0,0,0.1)] text-slate-900 dark:text-white' : 'text-slate-500 dark:text-slate-400' ?>
                       text-sm font-medium leading-normal transition-all"
                    >
                        <span class="truncate">S<?= $i ?></span>
                    </a>
                <?php endfor; ?>
            </div>
        </div>
        <!-- Courses Section -->
        <h2 class="text-slate-900 dark:text-white text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5">Matiére & SAÉs</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 p-4">

            <?php /** @var Matiere[] $matieres */ ?>
            <?php foreach ($matieres as $matiere): ?>

                <?php
                $code = $matiere->getCode();
                $prefix = strtoupper($code[0]);

                // Couleurs du card
                $colors = [
                        'R' => 'bg-pastel-blue/20 border-pastel-blue/30 dark:bg-pastel-blue/10 dark:border-pastel-blue/20',
                        'P' => 'bg-punchy-pink/20 border-punchy-pink/30 dark:bg-punchy-pink/10 dark:border-punchy-pink/20',
                        'S' => 'bg-bright-yellow/20 border-bright-yellow/30 dark:bg-bright-yellow/10 dark:border-bright-yellow/20',
                ];

                $colorClass = $colors[$prefix] ??
                        'bg-soft-purple/20 border-soft-purple/30 dark:bg-soft-purple/10 dark:border-soft-purple/20';

                // Couleurs icône
                $iconBg = match($prefix) {
                    'R' => 'bg-pastel-blue',
                    'P' => 'bg-punchy-pink',
                    'S' => 'bg-bright-yellow',
                    default => 'bg-soft-purple'
                };

                // Icône différente selon le type
                $icon = match($prefix) {
                    'R' => 'menu_book',     // Cours
                    'P' => 'assignment',    // Portfolio / Projet
                    'S' => 'work',          // Stage
                    default => 'help'       // Inconnu
                };

                // Responsable
                $prof = $matiere->getResponsable();
                $profName = $prof ? $prof->getPrenom() . " " . $prof->getNom() : "Non attribué";
                ?>

                <div class="flex flex-col gap-4 p-4 rounded-lg <?= $colorClass ?> transition-transform duration-300 ease-in-out hover:scale-105 hover:shadow-lg hover:shadow-black/20">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-full flex items-center justify-center text-white <?= $iconBg ?> transition-transform duration-300 ease-in-out group-hover:scale-110">
                            <span class="material-symbols-outlined"><?= $icon ?></span>
                        </div>

                        <p class="text-slate-800 dark:text-slate-100 text-base font-semibold leading-normal">
                            <?= $matiere->getCode() ?> - <?= $matiere->getNom() ?>
                        </p>
                    </div>

                    <p class="text-slate-600 dark:text-slate-400 text-sm leading-normal">
                        Responsable : <strong><?= $profName ?></strong>
                    </p>
                </div>

            <?php endforeach; ?>

        </div>

        <!-- Resources Section -->
        <h2 class="text-slate-900 dark:text-white text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5">Resources</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 p-4">
            <a class="flex items-center gap-4 p-4 rounded-lg bg-bright-yellow/20 dark:bg-bright-yellow/10 border border-bright-yellow/30 dark:border-bright-yellow/20 hover:shadow-lg hover:-translate-y-1 transition-all" href="#">
                <div class="w-10 h-10 rounded-full bg-bright-yellow flex items-center justify-center text-yellow-900"><span class="material-symbols-outlined">description</span></div>
                <p class="text-slate-800 dark:text-slate-100 text-base font-semibold">Lecture Notes</p>
            </a>
            <a class="flex items-center gap-4 p-4 rounded-lg bg-bright-yellow/20 dark:bg-bright-yellow/10 border border-bright-yellow/30 dark:border-bright-yellow/20 hover:shadow-lg hover:-translate-y-1 transition-all" href="#">
                <div class="w-10 h-10 rounded-full bg-bright-yellow flex items-center justify-center text-yellow-900"><span class="material-symbols-outlined">terminal</span></div>
                <p class="text-slate-800 dark:text-slate-100 text-base font-semibold">Lab Exercises</p>
            </a>
            <a class="flex items-center gap-4 p-4 rounded-lg bg-bright-yellow/20 dark:bg-bright-yellow/10 border border-bright-yellow/30 dark:border-bright-yellow/20 hover:shadow-lg hover:-translate-y-1 transition-all" href="#">
                <div class="w-10 h-10 rounded-full bg-bright-yellow flex items-center justify-center text-yellow-900"><span class="material-symbols-outlined">quiz</span></div>
                <p class="text-slate-800 dark:text-slate-100 text-base font-semibold">Past Exams</p>
            </a>
        </div>
    </main>
<?php
require_once '../app/views/_template/footer.php';
?>