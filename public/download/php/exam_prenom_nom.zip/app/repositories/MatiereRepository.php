<?php

require_once '../app/core/Repository.php';
require_once '../app/repositories/ResponsableRepository.php';

$matiereEntityPath = '../app/entities/Matiere.php';
if (file_exists($matiereEntityPath)) {
    require_once $matiereEntityPath;
}
class MatiereRepository
{
    private PDO $pdo;
    private ResponsableRepository $responsableRepo;

    public function __construct()
    {
        $this->pdo = Repository::getInstance()->getPDO();
        $this->responsableRepo = new ResponsableRepository();
    }

    private function createMatiereFromRow(array $row): Matiere
    {
        $responsable = null;

        if (!empty($row['responsable_id'])
            && method_exists($this->responsableRepo, 'findById')) {
            $responsable = $this->responsableRepo->findById((int) $row['responsable_id']);
        }

        return new Matiere(
            (int)$row['id'],
            $row['code'],
            $row['nom'],
            (int)$row['heures_td'],
            (int)$row['heures_tp'],
            $responsable,
            (int)$row['semestre']
        );
    }

    public function findBySemestre(int $semestre): array
    {
        $stmt = $this->pdo->prepare("
            SELECT *
            FROM matiere
            WHERE semestre = :semestre
        ");

        $stmt->execute(['semestre' => $semestre]);

        $matieres = [];

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $matieres[] = $this->createMatiereFromRow($row);
        }

        return $matieres;
    }
}
