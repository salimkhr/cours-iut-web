<?php
require_once '../app/core/Repository.php';
require_once '../app/entities/Card.php';

class CardRepository
{
    private $pdo;

    public function __construct()
    {
        $this->pdo = Repository::getInstance()->getPDO();
    }

    public function getTextQuestionCards(): Card
    {
        $stmt = $this->pdo->prepare("SELECT * FROM card where type = :type and theme_id = 1 ORDER BY RANDOM() limit 1");
        $stmt->execute(['type' => 'Question']);

        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $result = $this->createCardFromRow($row);

        return $result;
    }

    public function getReponseCards():array
    {
        $stmt = $this->pdo->prepare("SELECT * FROM card WHERE type = :type and theme_id = 1 ORDER BY RANDOM() limit 3");
        $stmt->execute(['type' => 'Réponse']);

        $result=[];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $result[] = $this->createCardFromRow($row);
        }

        return $result;
    }

    private function createCardFromRow(mixed $row)
    {
        return new Card($row['id'], $row['text'], $row['type'],'',1,true);
    }
}