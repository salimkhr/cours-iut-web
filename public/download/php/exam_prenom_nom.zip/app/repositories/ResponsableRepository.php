<?php
require_once '../app/core/Repository.php';

$responsableEntityPath = '../app/entities/Responsable.php';
if (file_exists($responsableEntityPath)) {
    require_once $responsableEntityPath;
}
class ResponsableRepository
{

}
