<?php

require_once '../app/core/Controller.php';
require_once '../app/services/GameService.php';
class GameController extends Controller
{
    private GameService $gameService;
    public function __construct()
    {
        $this->gameService  = new GameService();
    }
    public function index():void
    {
        $players = $this->gameService->players();

        if(empty($players))
            $this->redirectTo('init.php');
        $this->view('index','Un examen Limite Limite');
    }

    public function players()
    {
        $players = $this->gameService->players();
        $datas = [];

        /** @var User $player */
        foreach ($players as $player) {
            $data['nom'] = $player->getName();
            $data['score'] = $player->getScore();
            $data['position'] = $player->getPosition();
            $data['cartesBlanches'] = [];

            /** @var Card $card */
            foreach ($player->getCards() as $card)
            {
                $data['cartesBlanches'][] = ['texte'=>$card?->getText(), 'id'=>$card?->getId()];
            }

            $datas[]=$data;
        }

        $this->json($datas);
    }

    public function init()
    {
        $this->gameService->init();
        $this->redirectTo('index.php');
    }

    public function cards()
    {
        $this->json($_SESSION['card'] ?? 'Aucun Texte stocké en session !!!');
    }

    public function vote()
    {
        $this->view('vote','la Meilleure réponse est :');
    }

    public function finish()
    {
        $this->gameService->finish(htmlspecialchars($_GET['joueur']));
        $this->redirectTo('index.php');
    }
}
