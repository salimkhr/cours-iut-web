<?php
require_once '../app/core/Controller.php';
require_once '../app/repositories/MatiereRepository.php';

class IndexController extends Controller
{
    public function index()
    {
        $this->view('index', 'Accueil');
    }

    public function year()
    {
        $y = (int) ($_GET['y'] ?? 0);
        $s = isset($_GET['s']) ? (int) $_GET['s'] : 0;

        if ($y > 3 || $y < 1) {
            throw new Exception('Il n\'y a que 3 années dans le BUT');
        }

        // Définir l'année scolaire correspondante
        $schoolYear = match($y) {
            1 => '1ère année',
            default => $y . 'ème année',
        };

        // Calcul du semestre de base (semestre impair)
        $baseSemester = 2 * ($y - 1) + 1;

        // Déterminer le semestre actif
        if ($s >= 1 && $s <= 6) {
            // Si s est défini et valide, on l'utilise
            $semestreActif = $s;
        } else {
            // Sinon, calcul automatique selon la date
            $currentMonth = (int) date('n'); // 1 = janvier … 12 = décembre
            if ($currentMonth >= 7) {
                // Juillet à décembre → semestre pair
                $semestreActif = $baseSemester;
            } else {
                // Janvier à juin → semestre impair
                $semestreActif = $baseSemester + 1;
            }
        }

        $matieres = (new MatiereRepository())->findBySemestre($semestreActif);

        $this->view('year', $schoolYear, ['semestreActif' => $semestreActif, 'matieres' => $matieres]);
    }
}