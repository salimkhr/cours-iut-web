<?php
session_start();

require_once '../app/core/Controller.php';
require_once '../app/repositories/ResponsableRepository.php';
require_once '../app/repositories/MatiereRepository.php';
require_once '../app/trait/FormTrait.php';

$matiereEntityPath = '../app/entities/Matiere.php';
if (file_exists($matiereEntityPath)) {
    require_once $matiereEntityPath;
}

class AdminController extends Controller
{
    use FormTrait;

    public function index()
    {

    }
}
