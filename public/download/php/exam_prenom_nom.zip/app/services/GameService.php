<?php
require_once '../app/repositories/CardRepository.php';
require_once '../app/entities/User.php';

class GameService
{
    public function __construct()
    {
        if(session_status() == PHP_SESSION_NONE)
            session_start();
            //session_destroy(); //A décommenter si besoin de réinitialiser les sessions
    }

    public function cards():array
    {
       $cardRepository = new CardRepository();
       return $cardRepository->getReponseCards();
    }

    public function players():array
    {
        return []; //TODO a remplacé par la récupération des User dans $_SESSION['players'].
    }

    public function init()
    {
        /* initialisation des joueurs */

        $players = [];
        $players[] = new User('Alice','top');
        $players[] = new User('Bob','left');
        $players[] = new User('Célia','right');
        $players[] = new User('Etudiant','bottom');

        foreach ($players as $player) {
            $cards = $this->cards();
            $player->setCards($cards);
        }
        $cardRepository = new CardRepository();
        $questionCards = $cardRepository->getTextQuestionCards();

        //TODO : ajouter l'ensemble des players dans $_SESSION['players']
        //TODO : ajouter le contenu de $questionCards->getText() dans $_SESSION['card']

    }

    public function finish(int $winnerIndex)
    {
        $players = $this->players();

        $players[$winnerIndex]->setScore( $players[$winnerIndex]->getScore()+1);

        /** @var User $player */
        foreach ($players as $player) {
            $cards = $this->cards();
            $player->setCards($cards);
        }
        $cardRepository = new CardRepository();
        $questionCards = $cardRepository->getTextQuestionCards();

        $_SESSION["players"] = [];

        //TODO : ajouter l'ensemble des players en SESSION
        $_SESSION["card"] = $questionCards->getText();

        foreach ($players as $player) {
            $_SESSION["players"][] = serialize($player);
        }
    }

}