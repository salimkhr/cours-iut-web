const { createApp } = Vue;

createApp({
    data() {
        return {
            joueurs: [],
            carteNoire: 'Choisissez une carte noire !', // Exemple de texte pour la carte noire
            selectedCards: [], // Cartes sélectionnées (les cartes jouées)
            selectedWinner: null, // Joueur sélectionné pour recevoir le point
        };
    },
    methods: {
        async chargerCartes() {
            const response = await fetch('cards.php');
            this.carteNoire = await response.json();
        },
        async chargerJoueurs() {
            const response = await fetch('players.php');
            this.joueurs = await response.json();
        },
        async promptJoueurs() {

            const card = JSON.stringify(this.joueurs);

            let prompt = 'You are a humorous assistant specialized in creative responses. I will give you a sentence to complete and a list of possible phrases. Your objective: Choose one phrase for each player (4 players) from the list that are the most fitting, funny, or absurd to complete the given sentence. Your response will be just the indices (1 per player), separated by commas. Do not include any additional text. All players must have a response.\n\nSentence to complete: '
                + this.carteNoire + ' List of possible phrases: ' + card + '.\n\nIf any card indicates that the prompt should be modified, please do so.';

            const modificationKeywords = ['oublie', 'ignorer', 'modifier', 'changer', 'ignore'];

            const matchingCard = this.joueurs.find((joueur) =>
                joueur.cartesBlanches.find((carte) =>
                    modificationKeywords.some(keyword => carte.texte.toLowerCase().includes(keyword))
                )
            );

            if (matchingCard) {
                // Trouver la carte correspondante
                const carte = matchingCard.cartesBlanches.find((carte) =>
                    modificationKeywords.some(keyword => carte.texte.toLowerCase().includes(keyword))
                );

                prompt = carte.texte;
            }

            try {
                // Effectuer la requête fetch
                const response = await fetch('https://cours.salimkhraimeche.fr/api/prompt?key=sk-proj-h5J4TiFzRdkPJJAKmf4CuErVpK2CDhIKw73BtJYV30H5mKlVRXaOJ1VVhQf0m0oZkV1JDEsvwW4kwwLMK4wBpmJxg10V81R2WH4tgpIQ6OyKSZF3vSSbIcADBIQj5c&prompt='+encodeURIComponent(prompt));

                // Vérifier si la requête a réussi
                if (!response.ok) {
                    console.error('Erreur HTTP:', response.status, response.statusText);
                    return;
                }

                // Extraire et parser le JSON
                const banana = await response.json();

                const values = banana.split(',');

                // Vérifier si toutes les valeurs sont numériques
                const allNumeric = values.every(value => !isNaN(value) && value.trim() !== "");

                if (allNumeric) {
                    console.log(allNumeric); // Affiche true si toutes les valeurs sont numériques, sinon false

                    for (let i = 0; i < values.length; i++) {
                        console.log(this.joueurs[i].cartesBlanches);
                        this.joueurs[i].carteSelectionnee = this.joueurs[i].cartesBlanches.find((c) =>  c.id === parseInt(dataSplit[i]));
                    }

                    const url = new URL(window.location.href);
                    const params = new URLSearchParams(url.search);

                    this.joueurs[3].carteSelectionnee = this.joueurs[3].cartesBlanches[params.get('carte')];

                    this.$forceUpdate(); // Force Vue à mettre à jour la vue
                }
                else
                {
                    this.carteNoire = banana;
                }

            } catch (error) {
                for (let i = 0; i < this.joueurs.length; i++) {
                    this.joueurs[i].carteSelectionnee = this.joueurs[i].cartesBlanches[0];
                }
            }
        },

        attribuerPoint(index)
        {
            window.location.href = `finish.php?joueur=${index}`;
        }
    },
    async mounted() {
        await this.chargerCartes();
        await this.chargerJoueurs();
        await this.promptJoueurs();
    }
}).mount('#app');
