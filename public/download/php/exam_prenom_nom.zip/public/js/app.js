const { createApp } = Vue;

createApp({
    data() {
        return {
            titre: 'Un examen Limite Limite',
            carteNoire: "",
            joueurs: [],
            carteEnGlisse: null,
            cartesJouees: [],
            cartesJoueesAutomatique: [],
            animationEnCours: false, // Pour gérer l'animation
            cartesParJoueur: 1, // Nombre de cartes attendues par joueur
            joueursJouent: [0, 1, 2], // Liste des joueurs qui vont jouer automatiquement
        };
    },
    computed: {
        nombreDeTrous() {
            return (this.carteNoire.match(/______/g) || []).length;
        }
    },
    methods: {
        async chargerCartes() {
            const response = await fetch('cards.php');
            this.carteNoire = await response.json();
        },
        async chargerJoueurs() {
            const response = await fetch('players.php');
            this.joueurs = await response.json();
        },
        commencerGlisser(carte) {
            console.log("Carte en glisse :", carte);
            this.carteEnGlisse = carte;
        },
        highlightDropzone(active) {
            const dropzone = document.getElementById('carteNoire');
            if (active) {
                dropzone.classList.add('drag-over');
            } else {
                dropzone.classList.remove('drag-over');
            }
        },
        async deposerCarte() {
            // Vérifie si la carte peut être déposée (carteEnGlisse existe et qu'on a la place)
            if (this.carteEnGlisse && this.cartesJouees.length < this.nombreDeTrous) {
                // Ajouter la carte jouée à la liste des cartes jouées
                this.cartesJouees.push({ ...this.carteEnGlisse, jouee: true });
                console.log("Carte déposée :", this.carteEnGlisse);

                // Retirer la carte du joueur 3
                if (this.joueurs[3] && this.carteEnGlisse) {
                    const index = this.joueurs[3].cartesBlanches.findIndex(carte => carte.id === this.carteEnGlisse.id);
                    if (index !== -1) {
                        this.joueurs[3].cartesBlanches.splice(index, 1); // Enlève la carte de la main du joueur 3

                        setTimeout(() => {
                           window.location.replace('vote.php?carte=' + index);
                        }, 1000); // Animation dure 1 seconde
                    }
                }

                // Réinitialiser la carte en glisse après dépôt
                this.carteEnGlisse = null;
            } else {
                console.error("Impossible de déposer la carte !");
            }
        },

        async deposerCarteAuto() {
            // Vérifie si la carte peut être déposée (carteEnGlisse existe et qu'on a la place)
            if (this.carteEnGlisse && this.cartesJouees.length < this.nombreDeTrous) {
                this.cartesJoueesAutomatique.push({ ...this.carteEnGlisse, jouee: true });
                console.log("Carte déposée :", this.carteEnGlisse);
                this.carteEnGlisse = null;
            } else {
                console.error("Impossible de déposer la carte !");
            }
        },


        deposerCarteAutomatiquement(joueurIndex) {
            console.log(joueurIndex);

            const joueur = this.joueurs[joueurIndex];
            // Vérifie si l'animation est en cours ou si le joueur n'a pas encore déposé toutes ses cartes
            if (joueur.cartesBlanches.length === 0) return;
            for (let i = 0; i < this.nombreDeTrous; i++) {
                if (joueur.cartesBlanches[i]) {
                    const carte = joueur.cartesBlanches[i];
                    this.commencerGlisser(carte);
                    this.deposerCarteAuto(); // Déposer la carte
                    joueur.cartesBlanches.splice(i, 1); // Retirer la carte de la main du joueur à l'indice i
                }
            }
        },
        jouerAutomatiquement() {
            // Simule les actions des joueurs 0, 1, 2
            const intervalle = 1500; // Intervalle entre les actions de chaque joueur
            let joueurIndex = 0;
            const intervalId = setInterval(() => {
                if (joueurIndex < this.joueurs.length-1) {
                    this.deposerCarteAutomatiquement(joueurIndex);
                    joueurIndex++;
                } else {
                    clearInterval(intervalId);
                }
            }, intervalle);
        }
    },
    async mounted() {
        await this.chargerCartes();
        await this.chargerJoueurs();

        if (this.joueurs?.length > 0) {
            this.jouerAutomatiquement(); // Déclenche le jeu automatique
        } else {
            this.carteNoire = "/!\\ Aucun joueur trouvé !!! /!\\";
        }
    }
}).mount('#app');
