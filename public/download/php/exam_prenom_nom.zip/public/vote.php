<?php
require_once '../app/controllers/GameController.php';
(new GameController())->vote();