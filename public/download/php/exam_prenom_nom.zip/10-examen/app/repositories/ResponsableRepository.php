<?php
require_once '../app/core/Repository.php';
require_once '../app/entities/Responsable.php';

class ResponsableRepository
{

}
