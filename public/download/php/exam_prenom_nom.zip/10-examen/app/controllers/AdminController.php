<?php
session_start();

require_once '../app/core/Controller.php';
require_once '../app/repositories/ResponsableRepository.php';
require_once '../app/repositories/MatiereRepository.php';
require_once '../app/entities/Matiere.php';
require_once '../app/trait/FormTrait.php';

class AdminController extends Controller
{
    use FormTrait;

    public function index()
    {

    }
}
