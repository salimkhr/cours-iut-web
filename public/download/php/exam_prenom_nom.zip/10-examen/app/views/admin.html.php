<?php
require_once '../app/views/_template/header.php';
?>
    <div class="relative flex min-h-screen w-full flex-col group/design-root overflow-x-hidden">
        <div class="flex flex-grow">
            <!-- SideNavBar -->
            <aside class="flex flex-col w-64 p-4 bg-white dark:bg-background-dark dark:border-r dark:border-white/10 shrink-0">
                <div class="flex flex-col h-full justify-between">
                    <div class="flex flex-col gap-4">
                        <div class="flex items-center gap-3">
                            <div class="flex flex-col">
                                <h1 class="text-[#181013] dark:text-white text-base font-bold leading-normal">Admin Panel</h1>
                            </div>
                        </div>
                        <nav class="flex flex-col gap-2 mt-4">
                            <a class="flex items-center gap-3 px-3 py-2 rounded-full hover:bg-primary/10 dark:hover:bg-primary/20" href="#">
                                <span class="material-symbols-outlined text-[#181013] dark:text-white">grid_view</span>
                                <p class="text-[#181013] dark:text-white text-sm font-medium leading-normal">Dashboard</p>
                            </a>
                            <a class="flex items-center gap-3 px-3 py-2 rounded-full bg-primary/20 dark:bg-primary/30" href="#">
                                <span class="material-symbols-outlined text-primary" style="font-variation-settings: 'FILL' 1;">auto_stories</span>
                                <p class="text-primary text-sm font-bold leading-normal">Matières</p>
                            </a>
                            <a class="flex items-center gap-3 px-3 py-2 rounded-full hover:bg-primary/10 dark:hover:bg-primary/20" href="#">
                                <span class="material-symbols-outlined text-[#181013] dark:text-white">group</span>
                                <p class="text-[#181013] dark:text-white text-sm font-medium leading-normal">Professeurs</p>
                            </a>
                            <a class="flex items-center gap-3 px-3 py-2 rounded-full hover:bg-primary/10 dark:hover:bg-primary/20" href="#">
                                <span class="material-symbols-outlined text-[#181013] dark:text-white">school</span>
                                <p class="text-[#181013] dark:text-white text-sm font-medium leading-normal">Étudiants</p>
                            </a>
                            <a class="flex items-center gap-3 px-3 py-2 rounded-full hover:bg-primary/10 dark:hover:bg-primary/20" href="#">
                                <span class="material-symbols-outlined text-[#181013] dark:text-white">calendar_month</span>
                                <p class="text-[#181013] dark:text-white text-sm font-medium leading-normal">Calendrier</p>
                            </a>
                        </nav>
                    </div>
                    <div class="flex flex-col gap-1">
                        <a class="flex items-center gap-3 px-3 py-2 rounded-full hover:bg-primary/10 dark:hover:bg-primary/20" href="#">
                            <span class="material-symbols-outlined text-[#181013] dark:text-white">settings</span>
                            <p class="text-[#181013] dark:text-white text-sm font-medium leading-normal">Settings</p>
                        </a>
                        <a class="flex items-center gap-3 px-3 py-2 rounded-full hover:bg-primary/10 dark:hover:bg-primary/20" href="#">
                            <span class="material-symbols-outlined text-[#181013] dark:text-white">logout</span>
                            <p class="text-[#181013] dark:text-white text-sm font-medium leading-normal">Log Out</p>
                        </a>
                    </div>
                </div>
            </aside>
            <!-- Main Content -->
            <main class="flex-1 p-8 overflow-y-auto">
                <div class="max-w-4xl mx-auto">
                    <!-- Page Heading -->
                    <div class="flex items-center gap-4 mb-8">
                        <h1 class="text-[#181013] dark:text-white text-4xl font-black leading-tight tracking-[-0.033em]">Création d'une nouvelle matière</h1>
                    </div>
                    <!-- Form Container -->
                    <div class="bg-white dark:bg-black/20 rounded-lg p-8 shadow-sm">
                        <!-- Form -->
                    </div>
                </div>
            </main>
<?php
require_once '../app/views/_template/footer.php';
?>