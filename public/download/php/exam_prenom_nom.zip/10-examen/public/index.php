<?php
require_once '../app/controllers/IndexController.php';
(new IndexController())->index();
