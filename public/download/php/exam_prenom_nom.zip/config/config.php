<?php
// Définition de constantes pour la configuration de la base de données
define('DB_HOST', 'localhost');  // Hôte de la base de données
define('DB_NAME', 'postgres');  // Nom de la base de données
define('DB_USER', 'pizza');  // Nom d'utilisateur de la base de données
define('DB_PASS', 'sushi');  // Mot de passe de la base de données
define('DB_PORT', '5432');  // port de connection à la base de données