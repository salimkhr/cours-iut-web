<?php
// Définition de constantes pour la configuration de la base de données
define('DB_HOST', 'woody');  // Hôte de la base de données (généralement localhost)
define('DB_NAME', 'login');  // Nom de la base de données
define('DB_USER', 'login');  // Nom d'utilisateur de la base de données
define('DB_PASS', 'password');  // Mot de passe de la base de données
define('DB_PORT', '5432');  // Mot de passe de la base de données