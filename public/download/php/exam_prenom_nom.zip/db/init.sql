DROP TABLE IF EXISTS Card;
DROP TABLE IF EXISTS Theme;


CREATE TABLE Theme (
                       id SERIAL PRIMARY KEY,         -- Identifiant unique auto-incrémenté
                       name VARCHAR(100) NOT NULL     -- Nom du thème, limité à 100 caractères
);

CREATE TABLE Card (
                      id SERIAL PRIMARY KEY,                           -- Identifiant unique auto-incrémenté
                      text VARCHAR(200) NOT NULL,                      -- Contenu textuel limité à 200 caractères
                      theme_id INT NOT NULL,                           -- Clé étrangère vers la table Theme
                      type VARCHAR(50) NOT NULL CHECK (type IN ('Question', 'Réponse')), -- Type limité aux valeurs "Question" ou "Réponse"
                      response_count INT DEFAULT 0,                    -- Nombre de réponses associées (défaut : 0)
                      status BOOLEAN NOT NULL DEFAULT TRUE,            -- Statut actif (TRUE) ou inactif (FALSE)
                      CONSTRAINT fk_theme FOREIGN KEY (theme_id)       -- Relation avec la table Theme
                          REFERENCES Theme(id) ON DELETE CASCADE
);


-- Insertion des thèmes "Examen" et "Autres"
INSERT INTO Theme (name) VALUES
                             ('Examen'),
                             ('Autres');

INSERT INTO Card (text, theme_id, type, response_count, status)
VALUES
    ('Un orchestre de pingouins', 1, 'Réponse', 0, TRUE),

    ('Arriver à utiliser ChatGPT durant un examen (c''est possible ;-))', 1, 'Réponse', 0, TRUE),
    ('Gagner un mètre de shooter à la tombola du BDE (/!\\l''abus d''alcool/!\\)', 1, 'Réponse', 0, TRUE),
    ('Écrire une class avec classe', 1, 'Réponse', 0, TRUE),
    ('Faire la Java après un cours de Java', 1, 'Réponse', 0, TRUE),
    ('Avoir mis un gilet jaune à son pseudo', 1, 'Réponse', 0, TRUE),
    ('Des dizaines de fichiers ''backup_final_v2_vraiment_finale.zip''', 1, 'Réponse', 0, TRUE),
    ('Un tutoriel YouTube en coréen sous-titré en russe', 1, 'Réponse', 0, TRUE),
    ('Une commande Git qui efface tout le projet', 1, 'Réponse', 0, TRUE),
    ('Un bug résolu en redémarrant mon PC', 1, 'Réponse', 0, TRUE),
    ('Répondre "Ça marche sur ma machine" pendant une démo', 1, 'Réponse', 0, TRUE),
    ('Utiliser ''rm -rf'' sans y réfléchir et espérer que ça ne supprime pas la racine', 1, 'Réponse', 0, TRUE),
    ('Penser qu''un pointeur en C est "juste" une adresse mémoire, et se retrouver avec des "segfaults"', 1, 'Réponse', 0, TRUE),
    ('Créer une variable u et l''utiliser dans un malloc', 1, 'Réponse', 0, TRUE),
    ('Créer une variable banana et faire un split dessus', 1, 'Réponse', 0, TRUE),
    ('Écrire if(maVariable == true) return true else return false pour gagner des caractères', 1, 'Réponse', 0, TRUE),
    ('Réaliser qu''il faut faire une lettre de motivation personnalisée pour chaque entreprise et ne jamais la faire', 1, 'Réponse', 0, TRUE);

INSERT INTO Card (text, theme_id, type, response_count, status)
VALUES
    ('Le prof m’a mis un 0 en web parce qu’il a découvert que j’avais utilisé ______.', 1, 'Question', 0, TRUE),
    ('Si je passe la nuit à coder, c’est parce que je dois terminer ______ pour demain.', 1, 'Question', 0, TRUE),
    ('L''intelligence artificielle finira par remplacer ______.', 1, 'Question', 0, TRUE),
    ('Le truc que j''ai ajouté à mon CV juste pour impressionner les recruteurs, c''est ______.', 1, 'Question', 0, TRUE),
    ('La meilleure façon de se faire virer, c''est ______.', 1, 'Question', 0, TRUE),
    ('J’ai fait un commit, mais je viens de me rendre compte que j’ai ajouté ______ dans le projet.', 1, 'Question', 0, TRUE),
    ('Quand je veux corriger un bug, je me rends toujours compte que ______ est la vraie cause du problème.', 1, 'Question', 0, TRUE),
    ('La solution à tous les bugs, c’est ______.', 1, 'Question', 0, TRUE),
    ('Essayer d’utiliser Git sans savoir ce que fait "git pull" et se retrouver avec ______.', 1, 'Question', 0, TRUE),
    ('Passer des heures à chercher une erreur et découvrir que ______ était la cause du problème.', 1, 'Question', 0, TRUE),
    ('Faire un stage dans une entreprise où le projet consiste uniquement à ______.', 1, 'Question', 0, TRUE),
    ('Répondre à un e-mail de recruteur en disant que j’ai une "grande expérience en JavaScript" alors que j’ai écrit ______.', 1, 'Question', 0, TRUE),
    ('Envoyer 50 candidatures de stage et espérer qu’un recruteur remarque ______.', 1, 'Question', 0, TRUE),
    ('Se faire ban du Discord pour avoir ______ dans son pseudo.', 1, 'Question', 0, TRUE),
    ('Écrire une fonction en C avec des pointeurs mais oublier de ______.', 1, 'Question', 0, TRUE),
    ('Réussir à faire fonctionner mon projet après des heures de galère et me rendre compte que ______ était la solution tout du long.', 1, 'Question', 0, TRUE),
    ('Faire un backup du projet et le nommer "backup_final_v2_vraiment_finale.zip" pour être sûr que ça ne va jamais être effacé.', 1, 'Question', 0, TRUE),
    ('Ajouter un tutoriel YouTube en coréen sous-titré en russe pour ______.', 1, 'Question', 0, TRUE);